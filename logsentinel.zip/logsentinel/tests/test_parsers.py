import gzip
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from logsentinel.parsers import parse_auth_file, parse_auth_line, parse_web_line


class TestAuthParser(unittest.TestCase):
    def test_failed_password(self):
        e = parse_auth_line("Sep 21 10:15:32 web01 sshd[1234]: Failed password for root from 203.0.113.5 port 52211 ssh2", 2026)
        self.assertEqual((e.kind, e.user, e.ip, e.port), ("failed", "root", "203.0.113.5", 52211))
        self.assertEqual(e.timestamp, datetime(2026, 9, 21, 10, 15, 32))

    def test_failed_invalid_user(self):
        e = parse_auth_line("Sep  2 01:02:03 h sshd[1]: Failed password for invalid user oracle from 198.51.100.1 port 22 ssh2", 2026)
        self.assertEqual((e.kind, e.user), ("failed", "oracle"))
        self.assertEqual(e.timestamp.day, 2)

    def test_accepted_publickey(self):
        e = parse_auth_line("Sep 21 10:15:32 web01 sshd[99]: Accepted publickey for alice from 192.0.2.10 port 50000 ssh2", 2026)
        self.assertEqual((e.kind, e.user), ("accepted", "alice"))

    def test_invalid_user_without_port(self):
        e = parse_auth_line("Sep 21 10:15:32 web01 sshd[99]: Invalid user test from 198.51.100.7", 2026)
        self.assertEqual((e.kind, e.user, e.port), ("invalid_user", "test", None))

    def test_ipv6(self):
        e = parse_auth_line("Sep 21 10:15:32 h sshd[9]: Failed password for root from 2001:db8::1 port 4000 ssh2", 2026)
        self.assertEqual(e.ip, "2001:db8::1")

    def test_iso_timestamp(self):
        e = parse_auth_line("2026-09-21T10:15:32.123456+02:00 web01 sshd[1234]: Failed password for root from 203.0.113.5 port 1 ssh2")
        self.assertEqual(e.timestamp, datetime(2026, 9, 21, 10, 15, 32))

    def test_ignores_other_processes_and_noise(self):
        self.assertIsNone(parse_auth_line("Sep 21 10:17:01 web01 CRON[1]: Failed password for root from 1.2.3.4 port 1 ssh2", 2026))
        self.assertIsNone(parse_auth_line("Sep 21 10:17:01 web01 sshd[1]: Connection closed by 1.2.3.4 port 22", 2026))
        self.assertIsNone(parse_auth_line("n'importe quoi", 2026))

    def test_gzip_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "auth.log.gz"
            with gzip.open(path, "wt") as fh:
                fh.write("Sep 21 10:15:32 h sshd[1]: Failed password for root from 203.0.113.5 port 1 ssh2\nbruit\n")
            events, total = parse_auth_file(path, 2026)
            self.assertEqual((len(events), total), (1, 2))


class TestWebParser(unittest.TestCase):
    LINE = ('203.0.113.7 - - [21/Sep/2026:11:00:01 +0200] "GET /index.php?id=1 HTTP/1.1" 200 5123 '
            '"https://example.org/" "Mozilla/5.0"')

    def test_combined(self):
        e = parse_web_line(self.LINE)
        self.assertEqual((e.ip, e.method, e.path, e.status, e.size), ("203.0.113.7", "GET", "/index.php?id=1", 200, 5123))
        self.assertEqual((e.referrer, e.user_agent), ("https://example.org/", "Mozilla/5.0"))
        self.assertEqual(e.timestamp, datetime(2026, 9, 21, 11, 0, 1))

    def test_common_format_and_dash_size(self):
        e = parse_web_line('192.0.2.1 - bob [21/Sep/2026:11:00:01 +0000] "HEAD / HTTP/1.0" 304 -')
        self.assertEqual((e.size, e.user_agent), (0, ""))

    def test_escaped_quotes_in_user_agent(self):
        e = parse_web_line('192.0.2.1 - - [21/Sep/2026:11:00:01 +0000] "GET / HTTP/1.1" 200 1 "-" "evil \\"quoted\\" agent"')
        self.assertIn("quoted", e.user_agent)

    def test_malformed_request(self):
        e = parse_web_line('192.0.2.1 - - [21/Sep/2026:11:00:01 +0000] "\\x16\\x03\\x01" 400 0 "-" "-"')
        self.assertEqual(e.method, "-")

    def test_garbage(self):
        self.assertIsNone(parse_web_line("pas un log web"))


if __name__ == "__main__":
    unittest.main()
