import unittest
from datetime import datetime, timedelta

from logsentinel.config import Config
from logsentinel.detectors import (analyze, detect_ssh_bruteforce, detect_ssh_compromise,
                                   detect_ssh_password_spraying, detect_web_attacks,
                                   detect_web_enumeration, detect_web_flood, detect_web_scanners,
                                   window_peak)
from logsentinel.models import AuthEvent, Severity, WebEvent

T0 = datetime(2026, 9, 21, 10, 0, 0)


def auth(kind, ip="203.0.113.1", user="root", sec=0):
    return AuthEvent(T0 + timedelta(seconds=sec), "h", kind, user, ip, 22, f"{kind} {user} {ip}")


def web(path="/", ip="203.0.113.2", status=200, ua="Mozilla/5.0", sec=0.0):
    return WebEvent(T0 + timedelta(seconds=sec), ip, "GET", path, "HTTP/1.1", status, 0, "-", ua, f"{ip} {path}")


class TestWindowPeak(unittest.TestCase):
    def test_peak(self):
        times = [T0 + timedelta(seconds=s) for s in (0, 1, 2, 100, 101)]
        self.assertEqual(window_peak(times, 10)[0], 3)
        self.assertEqual(window_peak(times, 200)[0], 5)
        self.assertEqual(window_peak([], 10)[0], 0)


class TestSSH(unittest.TestCase):
    def test_bruteforce_triggers(self):
        events = [auth("failed", sec=i * 10) for i in range(6)]
        alerts = detect_ssh_bruteforce(events, Config())
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].rule, "SSH_BRUTE_FORCE")

    def test_bruteforce_below_threshold_or_slow(self):
        self.assertEqual(detect_ssh_bruteforce([auth("failed", sec=i) for i in range(4)], Config()), [])
        slow = [auth("failed", sec=i * 400) for i in range(10)]  # 1 échec toutes les 400s
        self.assertEqual(detect_ssh_bruteforce(slow, Config()), [])

    def test_compromise(self):
        events = [auth("failed", sec=i) for i in range(10)] + [auth("accepted", user="admin", sec=20)]
        alerts = detect_ssh_compromise(events, Config())
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].severity, Severity.CRITICAL)
        self.assertIn("admin", alerts[0].message)

    def test_no_compromise_for_normal_login(self):
        events = [auth("failed", ip="192.0.2.10", user="alice"), auth("accepted", ip="192.0.2.10", user="alice", sec=5)]
        self.assertEqual(detect_ssh_compromise(events, Config()), [])

    def test_spraying(self):
        events = [auth("invalid_user", user=u, sec=i) for i, u in enumerate(["a", "b", "c", "d", "e"])]
        alerts = detect_ssh_password_spraying(events, Config())
        self.assertEqual(alerts[0].rule, "SSH_PASSWORD_SPRAYING")

    def test_whitelist_cidr(self):
        events = [auth("failed", ip="10.1.2.3", sec=i) for i in range(20)]
        self.assertEqual(detect_ssh_bruteforce(events, Config(whitelist=["10.0.0.0/8"])), [])


class TestWeb(unittest.TestCase):
    def rules(self, events, cfg=None):
        return {a.rule for a in detect_web_attacks(events, cfg or Config())}

    def test_sqli_encoded(self):
        self.assertIn("WEB_SQL_INJECTION", self.rules([web("/p.php?id=1%20UNION%20SELECT%20password%20FROM%20users")]))
        self.assertIn("WEB_SQL_INJECTION", self.rules([web("/p.php?id=1%27%20OR%20%271%27%3D%271")]))

    def test_double_encoded_traversal(self):
        self.assertIn("WEB_PATH_TRAVERSAL", self.rules([web("/f?x=%252e%252e%252fetc%252fpasswd")]))

    def test_xss_cmdi_log4shell(self):
        self.assertIn("WEB_XSS", self.rules([web("/s?q=%3Cscript%3Ealert(1)%3C/script%3E")]))
        self.assertIn("WEB_COMMAND_INJECTION", self.rules([web("/ping?h=127.0.0.1;cat%20/etc/passwd")]))
        self.assertIn("WEB_LOG4SHELL", self.rules([web("/", ua="${jndi:ldap://x/a}")]))

    def test_escalation_on_success(self):
        ok = detect_web_attacks([web("/d?f=../../etc/passwd", status=200)], Config())[0]
        ko = detect_web_attacks([web("/d?f=../../etc/passwd", status=404)], Config())[0]
        self.assertEqual(ok.severity, Severity.CRITICAL)
        self.assertEqual(ko.severity, Severity.HIGH)

    def test_no_false_positive_on_normal_traffic(self):
        normal = [web(p) for p in ["/", "/blog/post-1", "/products.php?id=3", "/search?q=chaussures+rouges",
                                    "/static/app.js", "/contact?name=Or%C3%A9lie&ville=Lyon"]]
        self.assertEqual(detect_web_attacks(normal, Config()), [])
        self.assertEqual(detect_web_scanners(normal, Config()), [])

    def test_scanner_enumeration_flood(self):
        self.assertEqual(detect_web_scanners([web(ua="Nikto/2.5.0")], Config())[0].rule, "WEB_SCANNER_DETECTED")
        scan = [web(f"/x{i}", status=404, sec=i * 0.5) for i in range(25)]
        self.assertEqual(len(detect_web_enumeration(scan, Config())), 1)
        flood = [web(sec=i * 0.1) for i in range(400)]
        self.assertEqual(len(detect_web_flood(flood, Config())), 1)
        self.assertEqual(detect_web_flood(flood[:50], Config()), [])


class TestAnalyzeAndConfig(unittest.TestCase):
    def test_sorted_by_severity(self):
        events = [auth("failed", sec=i) for i in range(10)] + [auth("accepted", sec=20)]
        alerts = analyze(events, [web(ua="sqlmap/1.0")])
        ranks = [a.severity.rank for a in alerts]
        self.assertEqual(ranks, sorted(ranks, reverse=True))

    def test_invalid_config(self):
        with self.assertRaises(ValueError):
            Config(ssh_bruteforce_threshold=0)
        with self.assertRaises(ValueError):
            Config(whitelist=["pas-une-ip"])


if __name__ == "__main__":
    unittest.main()
