import io
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from logsentinel.cli import main


def run(*args):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        code = main(list(args))
    return code, out.getvalue(), err.getvalue()


class TestCLI(unittest.TestCase):
    def test_end_to_end_on_samples(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(run("generate-samples", "--out", tmp)[0], 0)
            report_json, report_html = Path(tmp) / "r.json", Path(tmp) / "r.html"
            code, out, _ = run("analyze", "--auth", f"{tmp}/auth.log", "--web", f"{tmp}/access.log",
                               "--year", "2026", "--json", str(report_json), "--html", str(report_html),
                               "--no-color", "--fail-on", "CRITICAL")
            self.assertEqual(code, 2)
            self.assertIn("SSH_SUCCESS_AFTER_BRUTE_FORCE", out)

            report = json.loads(report_json.read_text(encoding="utf-8"))
            rules = {a["rule"] for a in report["alerts"]}
            expected = {"SSH_BRUTE_FORCE", "SSH_PASSWORD_SPRAYING", "SSH_SUCCESS_AFTER_BRUTE_FORCE",
                        "WEB_SQL_INJECTION", "WEB_XSS", "WEB_PATH_TRAVERSAL", "WEB_COMMAND_INJECTION",
                        "WEB_LOG4SHELL", "WEB_SCANNER_DETECTED", "WEB_DIRECTORY_ENUMERATION", "WEB_REQUEST_FLOOD"}
            self.assertTrue(expected <= rules, expected - rules)
            # Aucune alerte ne doit viser le trafic légitime (192.0.2.10-80).
            legit = {f"192.0.2.{i}" for i in range(10, 81)}
            self.assertFalse(legit & {a["source_ip"] for a in report["alerts"]})
            html = report_html.read_text(encoding="utf-8")
            self.assertIn("Rapport LogSentinel", html)
            self.assertNotIn("<script>alert", html)  # les charges XSS doivent être échappées

    def test_min_severity_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            run("generate-samples", "--out", tmp)
            out_json = Path(tmp) / "r.json"
            run("analyze", "--web", f"{tmp}/access.log", "--min-severity", "critical", "-q", "--json", str(out_json))
            report = json.loads(out_json.read_text(encoding="utf-8"))
            self.assertTrue(report["alerts"])
            self.assertTrue(all(a["severity"] == "CRITICAL" for a in report["alerts"]))

    def test_errors(self):
        self.assertEqual(run("analyze")[0], 1)
        self.assertEqual(run("analyze", "--auth", "/fichier/inexistant")[0], 1)
        self.assertEqual(run("analyze", "--auth", "/dev/null", "--fail-on", "EXTREME")[0], 1)


if __name__ == "__main__":
    unittest.main()
