"""Permet l'exécution via ``python -m logsentinel``."""
import sys

from logsentinel.cli import main

if __name__ == "__main__":
    sys.exit(main())
