"""Signatures d'attaques web (inspirées des règles OWASP CRS, volontairement simplifiées)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Pattern
from urllib.parse import unquote_plus

from logsentinel.models import Severity


@dataclass(frozen=True)
class WebSignature:
    name: str
    description: str
    pattern: Pattern[str]
    severity: Severity
    mitre: str = "T1190"
    check_user_agent: bool = False


WEB_SIGNATURES = (
    WebSignature(
        "WEB_SQL_INJECTION", "Tentative d'injection SQL",
        re.compile(
            r"(?i)(\bunion\b.{0,40}\bselect\b|\b(?:and|or)\b\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+"
            r"|'\s*(?:or|and)\s*'|\bsleep\s*\(\s*\d+\s*\)|\bbenchmark\s*\(|\bwaitfor\s+delay\b"
            r"|information_schema|;\s*(?:drop|delete|insert|update)\s+|'\s*--|\bextractvalue\s*\()"
        ),
        Severity.HIGH,
    ),
    WebSignature(
        "WEB_XSS", "Tentative de Cross-Site Scripting (XSS)",
        re.compile(r"(?i)(<\s*script|javascript\s*:|\bon(?:error|load|mouseover|focus)\s*=|<\s*svg[^>]*\bon\w+\s*=|<\s*iframe)"),
        Severity.MEDIUM,
    ),
    WebSignature(
        "WEB_PATH_TRAVERSAL", "Tentative de traversée de répertoires / LFI",
        re.compile(r"(?i)(\.\./|\.\.\\|/etc/(?:passwd|shadow|hosts)|\bwin\.ini\b|\bboot\.ini\b|/proc/self/)"),
        Severity.HIGH,
    ),
    WebSignature(
        "WEB_COMMAND_INJECTION", "Tentative d'injection de commandes système",
        re.compile(r"(?i)(?:;|\|\|?|&&|`|\$\()\s*(?:cat|ls|id|whoami|wget|curl|nc|ncat|bash|sh|uname|ping|python\d?|perl)\b"),
        Severity.CRITICAL,
    ),
    WebSignature(
        "WEB_REMOTE_FILE_INCLUSION", "Tentative d'inclusion de fichier distant / wrapper PHP",
        re.compile(r"(?i)(php://(?:input|filter)|expect://|data://text|=\s*(?:https?|ftp)://[^&]*\.(?:txt|php)\b)"),
        Severity.HIGH,
    ),
    WebSignature(
        "WEB_SENSITIVE_FILE", "Accès à un fichier sensible",
        re.compile(
            r"(?i)/(?:\.env\b|\.git/|\.svn/|\.htpasswd|wp-config\.php|id_rsa|\.aws/credentials"
            r"|[\w-]+\.(?:sql|bak|old|swp)\b|phpinfo\.php)"
        ),
        Severity.MEDIUM,
        mitre="T1083",
    ),
    WebSignature(
        "WEB_LOG4SHELL", "Tentative d'exploitation Log4Shell (CVE-2021-44228)",
        re.compile(r"(?i)\$\{\s*(?:jndi|\$\{[^}]*\}[^}]*ndi)"),
        Severity.CRITICAL,
        check_user_agent=True,
    ),
)

SCANNER_USER_AGENT = re.compile(
    r"(?i)\b(sqlmap|nikto|nmap|masscan|dirbuster|gobuster|ffuf|feroxbuster|wpscan|zgrab"
    r"|nuclei|acunetix|nessus|openvas|hydra|wfuzz|whatweb|burp\s*collaborator)\b"
)


def normalize(value: str) -> str:
    """Double décodage URL pour contrer l'encodage simple ou double des charges utiles."""
    return unquote_plus(unquote_plus(value))
