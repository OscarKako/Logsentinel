"""Moteur de détection : chaque détecteur transforme une liste d'événements en alertes."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from logsentinel.config import Config
from logsentinel.models import Alert, AuthEvent, Severity, WebEvent
from logsentinel.signatures import SCANNER_USER_AGENT, WEB_SIGNATURES, WebSignature, normalize


def window_peak(times: Sequence[datetime], window: int) -> Tuple[int, Optional[datetime], Optional[datetime]]:
    """Nombre maximal d'événements dans une fenêtre glissante de ``window`` secondes.

    ``times`` doit être trié. Complexité O(n) grâce à deux pointeurs.
    """
    best: Tuple[int, Optional[datetime], Optional[datetime]] = (0, None, None)
    start = 0
    for end, current in enumerate(times):
        while (current - times[start]).total_seconds() > window:
            start += 1
        count = end - start + 1
        if count > best[0]:
            best = (count, times[start], current)
    return best


def _top(counter: Counter, n: int = 3) -> str:
    return ", ".join(f"{key or '<vide>'} ({count})" for key, count in counter.most_common(n))


def _group_by_ip(events, predicate, cfg: Config) -> Dict[str, list]:
    groups: Dict[str, list] = defaultdict(list)
    for event in events:
        if predicate(event) and not cfg.is_whitelisted(event.ip):
            groups[event.ip].append(event)
    for evs in groups.values():
        evs.sort(key=lambda e: e.timestamp)
    return groups


# --------------------------------------------------------------------------- SSH

def detect_ssh_bruteforce(events: List[AuthEvent], cfg: Config) -> List[Alert]:
    """Nombreux échecs d'authentification depuis une même IP dans une courte fenêtre."""
    alerts = []
    for ip, evs in _group_by_ip(events, lambda e: e.kind == "failed", cfg).items():
        peak, _, _ = window_peak([e.timestamp for e in evs], cfg.ssh_bruteforce_window)
        if peak < cfg.ssh_bruteforce_threshold:
            continue
        users = Counter(e.user for e in evs)
        alerts.append(Alert(
            rule="SSH_BRUTE_FORCE",
            severity=Severity.HIGH,
            source_ip=ip,
            message=(f"Force brute SSH : {peak} échecs en moins de {cfg.ssh_bruteforce_window}s "
                     f"({len(evs)} au total). Comptes ciblés : {_top(users)}"),
            first_seen=evs[0].timestamp,
            last_seen=evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in evs[: cfg.evidence_limit]],
            mitre="T1110.001",
        ))
    return alerts


def detect_ssh_password_spraying(events: List[AuthEvent], cfg: Config) -> List[Alert]:
    """Une IP qui teste de nombreux comptes différents (spraying / énumération d'utilisateurs)."""
    alerts = []
    groups = _group_by_ip(events, lambda e: e.kind in ("failed", "invalid_user"), cfg)
    for ip, evs in groups.items():
        users = {e.user for e in evs}
        if len(users) < cfg.ssh_spray_distinct_users:
            continue
        invalid = sorted({e.user for e in evs if e.kind == "invalid_user"})
        alerts.append(Alert(
            rule="SSH_PASSWORD_SPRAYING",
            severity=Severity.MEDIUM,
            source_ip=ip,
            message=(f"{len(users)} comptes différents testés depuis cette IP "
                     f"({len(invalid)} inexistants : {', '.join(invalid[:8]) or '-'})"),
            first_seen=evs[0].timestamp,
            last_seen=evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in evs[: cfg.evidence_limit]],
            mitre="T1110.003",
        ))
    return alerts


def detect_ssh_compromise(events: List[AuthEvent], cfg: Config) -> List[Alert]:
    """Connexion réussie précédée de nombreux échecs depuis la même IP : compte probablement compromis."""
    alerts = []
    failures: Dict[str, List[datetime]] = defaultdict(list)
    already_reported = set()
    for event in sorted(events, key=lambda e: e.timestamp):
        if cfg.is_whitelisted(event.ip):
            continue
        if event.kind == "failed":
            failures[event.ip].append(event.timestamp)
        elif event.kind == "accepted" and (event.ip, event.user) not in already_reported:
            since = event.timestamp - timedelta(seconds=cfg.compromise_lookback)
            prior = [t for t in failures[event.ip] if t >= since]
            if len(prior) >= cfg.ssh_bruteforce_threshold:
                already_reported.add((event.ip, event.user))
                alerts.append(Alert(
                    rule="SSH_SUCCESS_AFTER_BRUTE_FORCE",
                    severity=Severity.CRITICAL,
                    source_ip=event.ip,
                    message=(f"Connexion SSH RÉUSSIE pour '{event.user}' après {len(prior)} échecs "
                             f"depuis la même IP : compte probablement compromis"),
                    first_seen=prior[0],
                    last_seen=event.timestamp,
                    count=len(prior) + 1,
                    evidence=[event.raw],
                    mitre="T1078",
                ))
    return alerts


# --------------------------------------------------------------------------- Web

def _signature_target(event: WebEvent, sig: WebSignature) -> str:
    target = normalize(event.path)
    if sig.check_user_agent:
        target += " " + event.user_agent + " " + event.referrer
    return target


def detect_web_attacks(events: List[WebEvent], cfg: Config) -> List[Alert]:
    """Recherche de charges malveillantes connues (SQLi, XSS, LFI, RCE, Log4Shell...)."""
    groups: Dict[Tuple[str, str], Tuple[WebSignature, List[WebEvent]]] = {}
    for event in events:
        if cfg.is_whitelisted(event.ip):
            continue
        for sig in WEB_SIGNATURES:
            if sig.pattern.search(_signature_target(event, sig)):
                groups.setdefault((event.ip, sig.name), (sig, []))[1].append(event)

    alerts = []
    for (ip, _), (sig, evs) in groups.items():
        evs.sort(key=lambda e: e.timestamp)
        successes = [e for e in evs if 200 <= e.status < 300]
        message = f"{sig.description} : {len(evs)} requête(s)"
        severity = sig.severity
        if successes:
            severity = severity.escalate()
            message += f", dont {len(successes)} avec réponse 2xx — à vérifier en priorité"
        # On met en avant les requêtes ayant abouti dans les preuves.
        success_ids = {id(e) for e in successes}
        ordered = successes + [e for e in evs if id(e) not in success_ids]
        alerts.append(Alert(
            rule=sig.name,
            severity=severity,
            source_ip=ip,
            message=message,
            first_seen=evs[0].timestamp,
            last_seen=evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in ordered[: cfg.evidence_limit]],
            mitre=sig.mitre,
        ))
    return alerts


def detect_web_scanners(events: List[WebEvent], cfg: Config) -> List[Alert]:
    """User-Agents d'outils de scan / d'attaque automatisés."""
    alerts = []
    groups = _group_by_ip(events, lambda e: SCANNER_USER_AGENT.search(e.user_agent) is not None, cfg)
    for ip, evs in groups.items():
        tools = Counter(SCANNER_USER_AGENT.search(e.user_agent).group(1).lower() for e in evs)
        alerts.append(Alert(
            rule="WEB_SCANNER_DETECTED",
            severity=Severity.MEDIUM,
            source_ip=ip,
            message=f"Outil de scan identifié : {_top(tools)}",
            first_seen=evs[0].timestamp,
            last_seen=evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in evs[: cfg.evidence_limit]],
            mitre="T1595.002",
        ))
    return alerts


def detect_web_enumeration(events: List[WebEvent], cfg: Config) -> List[Alert]:
    """Rafale de réponses 404 : énumération de répertoires/fichiers (gobuster, dirb...)."""
    alerts = []
    for ip, evs in _group_by_ip(events, lambda e: e.status == 404, cfg).items():
        peak, _, _ = window_peak([e.timestamp for e in evs], cfg.web_404_window)
        if peak < cfg.web_404_threshold:
            continue
        alerts.append(Alert(
            rule="WEB_DIRECTORY_ENUMERATION",
            severity=Severity.MEDIUM,
            source_ip=ip,
            message=(f"Énumération de contenu : {peak} erreurs 404 en moins de "
                     f"{cfg.web_404_window}s ({len(evs)} au total)"),
            first_seen=evs[0].timestamp,
            last_seen=evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in evs[: cfg.evidence_limit]],
            mitre="T1595.003",
        ))
    return alerts


def detect_web_flood(events: List[WebEvent], cfg: Config) -> List[Alert]:
    """Volume de requêtes anormal depuis une seule IP (DoS applicatif, scraping agressif)."""
    alerts = []
    for ip, evs in _group_by_ip(events, lambda e: True, cfg).items():
        peak, start, end = window_peak([e.timestamp for e in evs], cfg.web_flood_window)
        if peak < cfg.web_flood_threshold:
            continue
        paths = Counter(e.path.split("?")[0] for e in evs)
        alerts.append(Alert(
            rule="WEB_REQUEST_FLOOD",
            severity=Severity.MEDIUM,
            source_ip=ip,
            message=(f"{peak} requêtes en moins de {cfg.web_flood_window}s. "
                     f"Ressources les plus visées : {_top(paths)}"),
            first_seen=start or evs[0].timestamp,
            last_seen=end or evs[-1].timestamp,
            count=len(evs),
            evidence=[e.raw for e in evs[: cfg.evidence_limit]],
            mitre="T1499",
        ))
    return alerts


AUTH_DETECTORS: List[Callable[[List[AuthEvent], Config], List[Alert]]] = [
    detect_ssh_bruteforce,
    detect_ssh_password_spraying,
    detect_ssh_compromise,
]
WEB_DETECTORS: List[Callable[[List[WebEvent], Config], List[Alert]]] = [
    detect_web_attacks,
    detect_web_scanners,
    detect_web_enumeration,
    detect_web_flood,
]


def analyze(auth_events: List[AuthEvent], web_events: List[WebEvent], cfg: Optional[Config] = None) -> List[Alert]:
    """Exécute tous les détecteurs et retourne les alertes triées (les plus graves d'abord)."""
    cfg = cfg or Config()
    alerts: List[Alert] = []
    for detector in AUTH_DETECTORS:
        alerts.extend(detector(auth_events, cfg))
    for detector in WEB_DETECTORS:
        alerts.extend(detector(web_events, cfg))
    alerts.sort(key=lambda a: (-a.severity.rank, a.first_seen, a.source_ip))
    return alerts


def compute_stats(auth_events: List[AuthEvent], web_events: List[WebEvent]) -> dict:
    """Statistiques globales pour le rapport."""
    kinds = Counter(e.kind for e in auth_events)
    return {
        "auth_events": len(auth_events),
        "ssh_failed": kinds.get("failed", 0),
        "ssh_accepted": kinds.get("accepted", 0),
        "ssh_invalid_user": kinds.get("invalid_user", 0),
        "top_ssh_failed_ips": Counter(e.ip for e in auth_events if e.kind == "failed").most_common(10),
        "web_requests": len(web_events),
        "web_unique_ips": len({e.ip for e in web_events}),
        "web_status": dict(sorted(Counter(f"{e.status // 100}xx" for e in web_events).items())),
        "top_web_ips": Counter(e.ip for e in web_events).most_common(10),
    }
