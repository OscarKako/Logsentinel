"""LogSentinel — détection d'intrusions à partir des journaux SSH et web."""

__version__ = "1.0.0"
__all__ = ["__version__"]
