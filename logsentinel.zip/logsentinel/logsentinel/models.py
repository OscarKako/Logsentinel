"""Modèles de données utilisés par LogSentinel."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional


class Severity(str, Enum):
    """Niveau de gravité d'une alerte."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    @property
    def rank(self) -> int:
        return _ORDER.index(self)

    def escalate(self) -> "Severity":
        """Retourne le niveau immédiatement supérieur (plafonné à CRITICAL)."""
        return _ORDER[min(self.rank + 1, len(_ORDER) - 1)]

    @classmethod
    def from_str(cls, value: str) -> "Severity":
        try:
            return cls(value.strip().upper())
        except ValueError as exc:
            raise ValueError(
                f"Sévérité inconnue : {value!r} (valeurs possibles : LOW, MEDIUM, HIGH, CRITICAL)"
            ) from exc


_ORDER = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]


@dataclass
class AuthEvent:
    """Événement d'authentification SSH extrait d'un auth.log."""

    timestamp: datetime
    host: str
    kind: str  # "failed", "accepted" ou "invalid_user"
    user: str
    ip: str
    port: Optional[int]
    raw: str


@dataclass
class WebEvent:
    """Requête HTTP extraite d'un access.log (format Apache/Nginx combined)."""

    timestamp: datetime
    ip: str
    method: str
    path: str
    protocol: str
    status: int
    size: int
    referrer: str
    user_agent: str
    raw: str


@dataclass
class Alert:
    """Alerte de sécurité produite par un détecteur."""

    rule: str
    severity: Severity
    source_ip: str
    message: str
    first_seen: datetime
    last_seen: datetime
    count: int = 1
    evidence: List[str] = field(default_factory=list)
    mitre: str = ""

    def to_dict(self) -> dict:
        return {
            "rule": self.rule,
            "severity": self.severity.value,
            "source_ip": self.source_ip,
            "message": self.message,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "count": self.count,
            "mitre": self.mitre,
            "evidence": list(self.evidence),
        }
