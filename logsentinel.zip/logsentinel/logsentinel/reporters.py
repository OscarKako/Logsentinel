"""Génération des rapports : console, JSON et HTML autonome."""
from __future__ import annotations

import html
import json
from collections import Counter
from datetime import datetime
from typing import List

from logsentinel import __version__
from logsentinel.models import Alert, Severity

_ANSI = {
    Severity.LOW: "\033[36m",
    Severity.MEDIUM: "\033[33m",
    Severity.HIGH: "\033[31m",
    Severity.CRITICAL: "\033[1;97;41m",
}
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"


def severity_summary(alerts: List[Alert]) -> dict:
    counts = Counter(a.severity for a in alerts)
    return {sev.value: counts.get(sev, 0) for sev in reversed(list(Severity))}


def render_console(alerts: List[Alert], stats: dict, color: bool = True) -> str:
    def c(code: str, text: str) -> str:
        return f"{code}{text}{_RESET}" if color else text

    out = [c(_BOLD, f"\n=== LogSentinel {__version__} — rapport d'analyse ===\n")]
    out.append(
        f"Événements SSH : {stats['auth_events']} "
        f"(échecs : {stats['ssh_failed']}, succès : {stats['ssh_accepted']}, "
        f"utilisateurs invalides : {stats['ssh_invalid_user']})"
    )
    out.append(f"Requêtes web   : {stats['web_requests']} depuis {stats['web_unique_ips']} IP distinctes "
               f"{stats['web_status'] or ''}")
    summary = severity_summary(alerts)
    out.append("Alertes        : " + "  ".join(
        c(_ANSI[Severity(k)], f"{k}={v}") for k, v in summary.items()) + "\n")

    if not alerts:
        out.append(c("\033[32m", "Aucune activité suspecte détectée."))
        return "\n".join(out)

    for i, alert in enumerate(alerts, 1):
        tag = c(_ANSI[alert.severity], f" {alert.severity.value:<8} ")
        out.append(f"{tag} #{i:<3} {c(_BOLD, alert.rule)}  [{alert.mitre}]  source : {alert.source_ip}")
        out.append(f"           {alert.message}")
        out.append(c(_DIM, f"           {alert.first_seen:%Y-%m-%d %H:%M:%S} → "
                           f"{alert.last_seen:%Y-%m-%d %H:%M:%S}  ({alert.count} événement(s))"))
        if alert.evidence:
            out.append(c(_DIM, f"           ex. : {alert.evidence[0][:160]}"))
        out.append("")
    return "\n".join(out)


def build_report(alerts: List[Alert], stats: dict, sources: dict) -> dict:
    return {
        "generator": f"LogSentinel {__version__}",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "sources": sources,
        "summary": severity_summary(alerts),
        "stats": stats,
        "alerts": [a.to_dict() for a in alerts],
    }


def render_json(report: dict) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False)


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rapport LogSentinel</title>
<style>
  :root {{ --bg:#0f1419; --panel:#182028; --text:#e6e9ec; --muted:#8b97a3; --border:#26313c;
          --low:#3ba7c9; --medium:#e0a526; --high:#e5533d; --critical:#ff2d55; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; background:var(--bg);
         color:var(--text); line-height:1.5; }}
  main {{ max-width:1200px; margin:0 auto; padding:32px 20px; }}
  h1 {{ margin:0 0 4px; font-size:1.7rem; }} h2 {{ margin-top:36px; font-size:1.2rem; }}
  .muted {{ color:var(--muted); font-size:.9rem; }}
  .cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; margin-top:24px; }}
  .card {{ background:var(--panel); border:1px solid var(--border); border-radius:10px; padding:16px; }}
  .card .n {{ font-size:1.9rem; font-weight:700; }}
  .card.CRITICAL .n {{ color:var(--critical); }} .card.HIGH .n {{ color:var(--high); }}
  .card.MEDIUM .n {{ color:var(--medium); }} .card.LOW .n {{ color:var(--low); }}
  .table-wrap {{ overflow-x:auto; }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border-radius:10px; overflow:hidden; }}
  th, td {{ padding:10px 12px; text-align:left; border-bottom:1px solid var(--border); vertical-align:top; font-size:.92rem; }}
  th {{ color:var(--muted); font-weight:600; text-transform:uppercase; font-size:.75rem; letter-spacing:.04em; }}
  .sev {{ display:inline-block; padding:2px 8px; border-radius:4px; font-weight:700; font-size:.75rem; color:#fff; }}
  .sev.CRITICAL {{ background:var(--critical); }} .sev.HIGH {{ background:var(--high); }}
  .sev.MEDIUM {{ background:var(--medium); color:#111; }} .sev.LOW {{ background:var(--low); }}
  code, pre {{ font-family:ui-monospace,"SFMono-Regular",Consolas,monospace; font-size:.8rem; }}
  pre {{ white-space:pre-wrap; word-break:break-all; background:#0b0f13; padding:10px; border-radius:6px; margin:8px 0 0; }}
  details summary {{ cursor:pointer; color:var(--muted); }}
  a {{ color:var(--low); }}
  .grid2 {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:16px; }}
</style>
</head>
<body>
<main>
  <h1>🛡️ Rapport LogSentinel</h1>
  <div class="muted">Généré le {generated_at} par {generator} — sources : {sources}</div>

  <div class="cards">
    {cards}
    <div class="card"><div class="n">{auth_events}</div><div class="muted">événements SSH</div></div>
    <div class="card"><div class="n">{web_requests}</div><div class="muted">requêtes web</div></div>
  </div>

  <h2>Alertes ({alert_count})</h2>
  <div class="table-wrap">
  <table>
    <thead><tr><th>Sévérité</th><th>Règle</th><th>Source</th><th>Détails</th><th>Période</th><th>MITRE</th></tr></thead>
    <tbody>
    {rows}
    </tbody>
  </table>
  </div>

  <div class="grid2">
    <div><h2>Top IP — échecs SSH</h2><div class="table-wrap"><table><tbody>{top_ssh}</tbody></table></div></div>
    <div><h2>Top IP — requêtes web</h2><div class="table-wrap"><table><tbody>{top_web}</tbody></table></div></div>
  </div>
</main>
</body>
</html>
"""


def _top_rows(pairs) -> str:
    if not pairs:
        return '<tr><td class="muted">Aucune donnée</td></tr>'
    return "".join(f"<tr><td><code>{html.escape(ip)}</code></td><td>{n}</td></tr>" for ip, n in pairs)


def render_html(report: dict) -> str:
    esc = html.escape
    rows = []
    for a in report["alerts"]:
        evidence = "".join(f"<pre>{esc(line)}</pre>" for line in a["evidence"])
        mitre = a["mitre"]
        mitre_link = (
            f'<a href="https://attack.mitre.org/techniques/{esc(mitre.replace(".", "/"))}/" '
            f'target="_blank" rel="noopener">{esc(mitre)}</a>' if mitre else "-"
        )
        rows.append(
            f'<tr><td><span class="sev {esc(a["severity"])}">{esc(a["severity"])}</span></td>'
            f'<td><code>{esc(a["rule"])}</code></td><td><code>{esc(a["source_ip"])}</code></td>'
            f'<td>{esc(a["message"])}<details><summary>{a["count"]} événement(s) — preuves</summary>{evidence}</details></td>'
            f'<td class="muted">{esc(a["first_seen"].replace("T", " "))}<br>→ {esc(a["last_seen"].replace("T", " "))}</td>'
            f"<td>{mitre_link}</td></tr>"
        )
    if not rows:
        rows.append('<tr><td colspan="6">✅ Aucune activité suspecte détectée.</td></tr>')

    cards = "".join(
        f'<div class="card {sev}"><div class="n">{n}</div><div class="muted">{sev}</div></div>'
        for sev, n in report["summary"].items()
    )
    stats = report["stats"]
    sources = ", ".join(esc(p) for paths in report["sources"].values() for p in paths) or "-"
    return _HTML_TEMPLATE.format(
        generated_at=esc(report["generated_at"].replace("T", " ")),
        generator=esc(report["generator"]),
        sources=sources,
        cards=cards,
        auth_events=stats["auth_events"],
        web_requests=stats["web_requests"],
        alert_count=len(report["alerts"]),
        rows="\n    ".join(rows),
        top_ssh=_top_rows(stats["top_ssh_failed_ips"]),
        top_web=_top_rows(stats["top_web_ips"]),
    )
