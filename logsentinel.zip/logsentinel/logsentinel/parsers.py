"""Analyseurs (parsers) pour les journaux auth.log (sshd) et access.log (Apache/Nginx)."""
from __future__ import annotations

import gzip
import re
from datetime import datetime
from pathlib import Path
from typing import IO, List, Optional, Tuple, Union

from logsentinel.models import AuthEvent, WebEvent

MONTHS = {
    name: idx
    for idx, name in enumerate(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], start=1
    )
}

# --- auth.log ---------------------------------------------------------------
# Format syslog classique :  "Sep 21 10:15:32 web01 sshd[1234]: message"
_SYSLOG_RE = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+"
    r"(?P<host>\S+)\s+(?P<proc>[^\s:\[]+)(?:\[\d+\])?:\s*(?P<msg>.*)$"
)
# Format ISO 8601 (rsyslog récent) : "2026-09-21T10:15:32.123456+02:00 web01 sshd[1234]: message"
_ISO_RE = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\s+"
    r"(?P<host>\S+)\s+(?P<proc>[^\s:\[]+)(?:\[\d+\])?:\s*(?P<msg>.*)$"
)
_IP = r"(?P<ip>[0-9A-Fa-f.:]+)"
_AUTH_PATTERNS = (
    ("failed", re.compile(
        r"Failed (?:password|publickey|keyboard-interactive/pam) for (?:invalid user )?(?P<user>\S*) from "
        + _IP + r" port (?P<port>\d+)")),
    ("accepted", re.compile(
        r"Accepted (?:password|publickey|keyboard-interactive/pam) for (?P<user>\S+) from "
        + _IP + r" port (?P<port>\d+)")),
    ("invalid_user", re.compile(
        r"Invalid user (?P<user>\S*) from " + _IP + r"(?: port (?P<port>\d+))?")),
)

# --- access.log (combined) --------------------------------------------------
_QUOTED = r'((?:[^"\\]|\\.)*)'
_WEB_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "' + _QUOTED.replace("(", "(?P<request>", 1) + r'" '
    r"(?P<status>\d{3}) (?P<size>\d+|-)"
    r'(?: "' + _QUOTED.replace("(", "(?P<ref>", 1) + r'" "' + _QUOTED.replace("(", "(?P<ua>", 1) + r'")?'
)
_WEB_TS_RE = re.compile(
    r"^(?P<day>\d{2})/(?P<month>[A-Za-z]{3})/(?P<year>\d{4}):(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2})"
)


def parse_auth_line(line: str, year: Optional[int] = None) -> Optional[AuthEvent]:
    """Analyse une ligne d'auth.log. Retourne ``None`` si la ligne n'est pas un événement sshd pertinent.

    Le format syslog classique ne contient pas l'année : ``year`` permet de la préciser
    (année courante par défaut).
    """
    line = line.rstrip("\r\n")
    m = _SYSLOG_RE.match(line)
    if m:
        month = MONTHS.get(m.group("month"))
        if month is None:
            return None
        h, mi, s = (int(x) for x in m.group("time").split(":"))
        try:
            ts = datetime(year or datetime.now().year, month, int(m.group("day")), h, mi, s)
        except ValueError:
            return None
    else:
        m = _ISO_RE.match(line)
        if not m:
            return None
        ts = datetime.strptime(m.group("ts"), "%Y-%m-%dT%H:%M:%S")

    if not m.group("proc").startswith("sshd"):
        return None

    msg = m.group("msg")
    for kind, regex in _AUTH_PATTERNS:
        found = regex.search(msg)
        if found:
            port = found.group("port")
            return AuthEvent(
                timestamp=ts,
                host=m.group("host"),
                kind=kind,
                user=found.group("user"),
                ip=found.group("ip"),
                port=int(port) if port else None,
                raw=line,
            )
    return None


def _parse_web_timestamp(value: str) -> Optional[datetime]:
    m = _WEB_TS_RE.match(value)
    if not m:
        return None
    month = MONTHS.get(m.group("month").capitalize())
    if month is None:
        return None
    try:
        # L'heure locale du serveur est conservée (le fuseau est ignoré volontairement
        # afin de rester comparable aux horodatages naïfs d'auth.log).
        return datetime(int(m.group("year")), month, int(m.group("day")),
                        int(m.group("h")), int(m.group("m")), int(m.group("s")))
    except ValueError:
        return None


def parse_web_line(line: str) -> Optional[WebEvent]:
    """Analyse une ligne d'access.log au format *common* ou *combined*."""
    line = line.rstrip("\r\n")
    m = _WEB_RE.match(line)
    if not m:
        return None
    ts = _parse_web_timestamp(m.group("ts"))
    if ts is None:
        return None

    request = m.group("request")
    parts = request.split(" ")
    if len(parts) >= 2:
        method, path, protocol = parts[0], parts[1], " ".join(parts[2:])
    else:  # requête malformée (ex. : handshake TLS envoyé sur un port HTTP)
        method, path, protocol = "-", request, ""

    size = m.group("size")
    return WebEvent(
        timestamp=ts,
        ip=m.group("ip"),
        method=method,
        path=path,
        protocol=protocol,
        status=int(m.group("status")),
        size=0 if size == "-" else int(size),
        referrer=m.group("ref") or "",
        user_agent=m.group("ua") or "",
        raw=line,
    )


def open_log(path: Union[str, Path]) -> IO[str]:
    """Ouvre un journal texte, éventuellement compressé en gzip (logrotate)."""
    path = Path(path)
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, encoding="utf-8", errors="replace")


def parse_auth_file(path: Union[str, Path], year: Optional[int] = None) -> Tuple[List[AuthEvent], int]:
    """Retourne (événements, nombre total de lignes lues)."""
    events: List[AuthEvent] = []
    total = 0
    with open_log(path) as fh:
        for line in fh:
            total += 1
            event = parse_auth_line(line, year)
            if event:
                events.append(event)
    return events, total


def parse_web_file(path: Union[str, Path]) -> Tuple[List[WebEvent], int]:
    """Retourne (événements, nombre total de lignes lues)."""
    events: List[WebEvent] = []
    total = 0
    with open_log(path) as fh:
        for line in fh:
            total += 1
            event = parse_web_line(line)
            if event:
                events.append(event)
    return events, total
