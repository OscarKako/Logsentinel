"""Interface en ligne de commande de LogSentinel."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from logsentinel import __version__
from logsentinel.config import Config
from logsentinel.detectors import analyze, compute_stats
from logsentinel.models import Severity
from logsentinel.parsers import parse_auth_file, parse_web_file
from logsentinel.reporters import build_report, render_console, render_html, render_json
from logsentinel.samples import generate_samples

EXIT_OK, EXIT_ERROR, EXIT_ALERTS = 0, 1, 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="logsentinel",
        description="Détection d'intrusions à partir des journaux SSH (auth.log) et web (access.log).",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    a = sub.add_parser("analyze", help="analyser des fichiers de logs")
    a.add_argument("--auth", action="append", default=[], metavar="FICHIER",
                   help="journal SSH (auth.log / secure), .gz accepté ; option répétable")
    a.add_argument("--web", action="append", default=[], metavar="FICHIER",
                   help="journal web Apache/Nginx (combined), .gz accepté ; option répétable")
    a.add_argument("--year", type=int, help="année des logs syslog (qui ne la contiennent pas)")
    a.add_argument("--config", metavar="JSON", help="fichier de configuration des seuils")
    a.add_argument("--json", dest="json_out", metavar="FICHIER", help="écrire le rapport JSON")
    a.add_argument("--html", dest="html_out", metavar="FICHIER", help="écrire le rapport HTML")
    a.add_argument("--min-severity", default="LOW", help="n'afficher que les alertes >= ce niveau")
    a.add_argument("--fail-on", metavar="NIVEAU",
                   help="code de sortie 2 si une alerte >= NIVEAU est trouvée (utile en cron/CI)")
    a.add_argument("--no-color", action="store_true", help="désactiver les couleurs ANSI")
    a.add_argument("-q", "--quiet", action="store_true", help="ne rien afficher sur la console")

    g = sub.add_parser("generate-samples", help="générer des logs de démonstration contenant des attaques")
    g.add_argument("--out", default="samples", help="dossier de sortie (défaut : samples)")
    g.add_argument("--seed", type=int, default=42, help="graine aléatoire (reproductibilité)")
    return parser


def _cmd_analyze(args: argparse.Namespace) -> int:
    if not args.auth and not args.web:
        print("Erreur : indiquez au moins un fichier avec --auth ou --web.", file=sys.stderr)
        return EXIT_ERROR

    min_sev = Severity.from_str(args.min_severity)
    fail_on = Severity.from_str(args.fail_on) if args.fail_on else None
    cfg = Config.load(args.config) if args.config else Config()

    auth_events, web_events = [], []
    for path in args.auth:
        events, total = parse_auth_file(path, args.year)
        auth_events.extend(events)
        if not args.quiet:
            print(f"[+] {path} : {total} lignes, {len(events)} événements SSH retenus", file=sys.stderr)
    for path in args.web:
        events, total = parse_web_file(path)
        web_events.extend(events)
        if not args.quiet:
            print(f"[+] {path} : {total} lignes, {len(events)} requêtes analysées", file=sys.stderr)

    alerts = [a for a in analyze(auth_events, web_events, cfg) if a.severity.rank >= min_sev.rank]
    stats = compute_stats(auth_events, web_events)
    report = build_report(alerts, stats, {"auth": args.auth, "web": args.web})

    if not args.quiet:
        color = not args.no_color and sys.stdout.isatty()
        print(render_console(alerts, stats, color=color))
    if args.json_out:
        Path(args.json_out).write_text(render_json(report), encoding="utf-8")
        if not args.quiet:
            print(f"[+] Rapport JSON : {args.json_out}", file=sys.stderr)
    if args.html_out:
        Path(args.html_out).write_text(render_html(report), encoding="utf-8")
        if not args.quiet:
            print(f"[+] Rapport HTML : {args.html_out}", file=sys.stderr)

    if fail_on and any(a.severity.rank >= fail_on.rank for a in alerts):
        return EXIT_ALERTS
    return EXIT_OK


def _cmd_generate(args: argparse.Namespace) -> int:
    auth, web = generate_samples(args.out, args.seed)
    print(f"[+] Logs de démonstration générés :\n    {auth}\n    {web}")
    print(f"\nEssayez :\n    logsentinel analyze --auth {auth} --web {web} --year 2026 --html rapport.html")
    return EXIT_OK


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "analyze":
            return _cmd_analyze(args)
        return _cmd_generate(args)
    except (OSError, ValueError) as exc:
        print(f"Erreur : {exc}", file=sys.stderr)
        return EXIT_ERROR
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
