"""Configuration des seuils de détection."""
from __future__ import annotations

import ipaddress
import json
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import List, Union


@dataclass
class Config:
    """Seuils et options des détecteurs. Les fenêtres sont exprimées en secondes."""

    ssh_bruteforce_threshold: int = 5
    ssh_bruteforce_window: int = 300
    ssh_spray_distinct_users: int = 5
    compromise_lookback: int = 3600
    web_404_threshold: int = 20
    web_404_window: int = 60
    web_flood_threshold: int = 300
    web_flood_window: int = 60
    evidence_limit: int = 5
    whitelist: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        for f in fields(self):
            if f.name == "whitelist":
                continue
            value = getattr(self, f.name)
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"'{f.name}' doit être un entier strictement positif (reçu : {value!r})")
        self._networks = []
        for entry in self.whitelist:
            try:
                self._networks.append(ipaddress.ip_network(entry, strict=False))
            except ValueError as exc:
                raise ValueError(f"Entrée de whitelist invalide : {entry!r}") from exc

    def is_whitelisted(self, ip: str) -> bool:
        if not self._networks:
            return False
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(addr in net for net in self._networks)

    @classmethod
    def load(cls, path: Union[str, Path]) -> "Config":
        """Charge une configuration JSON ; les clés absentes gardent leur valeur par défaut."""
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            raise ValueError("Le fichier de configuration doit contenir un objet JSON.")
        known = {f.name for f in fields(cls)}
        unknown = set(data) - known
        if unknown:
            raise ValueError(f"Clé(s) de configuration inconnue(s) : {', '.join(sorted(unknown))}")
        return cls(**data)
